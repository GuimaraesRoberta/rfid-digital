/*****************************************************************************

    Copyright 2010-2013
    Fraunhofer-Gesellschaft zur Foerderung der angewandten Forschung e.V.


   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 *****************************************************************************/

/*****************************************************************************

 sca_tdf_port_attributes.cpp - description

 Original Author: Karsten Einwich Fraunhofer IIS/EAS Dresden

 Created on: 27.08.2009

 SVN Version       :  $Revision: 1479 $
 SVN last checkin  :  $Date: 2013-01-20 17:18:34 +0100 (Sun, 20 Jan 2013) $
 SVN checkin by    :  $Author: karsten $
 SVN Id            :  $Id: sca_tdf_port_attributes.cpp 1479 2013-01-20 16:18:34Z karsten $

 *****************************************************************************/

/*****************************************************************************/

#include <systemc-ams>
#include "scams/impl/predefined_moc/tdf/sca_tdf_port_attributes.h"
#include "scams/impl/core/sca_simcontext.h"


namespace sca_tdf
{

namespace sca_implementation
{

const unsigned long& sca_port_attributes::get_rate() const
{
	if(!pobj->elaboration_finished)
	{
		std::ostringstream str;
		str << "get_rate() for port: " << pobj->sca_name();
		str << " can only be called after elaboration (see LRM)";
		SC_REPORT_ERROR("SystemC-AMS",str.str().c_str());
	}

	return rate;
}


const unsigned long& sca_port_attributes::get_delay() const
{
	if(!pobj->elaboration_finished)
	{
		std::ostringstream str;
		str << "get_delay() for port: " << pobj->sca_name();
		str << " can only be called after elaboration (see LRM)";
		SC_REPORT_ERROR("SystemC-AMS",str.str().c_str());
	}

	return delay;
}

const sca_core::sca_time& sca_port_attributes::get_timestep() const
{
	if(!pobj->elaboration_finished)
	{
		std::ostringstream str;
		str << "get_timestep() for port: " << pobj->sca_name();
		str << " can only be called after elaboration (see LRM)";
		SC_REPORT_ERROR("SystemC-AMS",str.str().c_str());
	}

	return timestep_calculated;
}

const sca_core::sca_time& sca_port_attributes::get_timeoffset() const
{
	if(!pobj->elaboration_finished)
	{
		std::ostringstream str;
		str << "get_timeoffset() for port: " << pobj->sca_name();
		str << " can only be called after elaboration (see LRM)";
		SC_REPORT_ERROR("SystemC-AMS",str.str().c_str());
	}

	return timeoffset_calculated;
}



void sca_port_attributes::set_rate(unsigned long rate_)
{
	rate=rate_;
}


void sca_port_attributes::set_delay(unsigned long delay_)
{
	delay=delay_;
}

void sca_port_attributes::set_timestep(const sca_core::sca_time& timestep_)
{
	timestep=timestep_;
	timestep_calculated=timestep_;
}


void sca_port_attributes::set_timeoffset(const sca_core::sca_time& timeoffset_)
{
	timeoffset=timeoffset_;
	timeoffset_calculated=timeoffset_;
}

sca_port_attributes::sca_port_attributes(sca_core::sca_implementation::sca_port_base* port):
		pobj(port)
{
	rate=1;
	delay=0;
	timeoffset=sc_core::SC_ZERO_TIME;
	timestep=sca_core::sca_implementation::NOT_VALID_SCA_TIME();

	timeoffset_calculated=sc_core::SC_ZERO_TIME;
	timestep_calculated=sca_core::sca_implementation::NOT_VALID_SCA_TIME();
}


void sca_port_attributes::initialize_all_traces()
{
	sca_core::sca_implementation::sca_get_curr_simcontext()->initialize_all_traces();
}

}
}

